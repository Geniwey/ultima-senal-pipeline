# Última Señal — Infraestructura completa del pipeline

## Visión general

```
TEMA (tú lo eliges)
   │
   ▼
1. GUION (Groq)  ──────────────► guion.json (12-18 escenas)
   │
   ▼
2. VOZ (Edge TTS) ─────────────► un mp3 por escena + duración exacta
   │
   ▼
3. IMÁGENES (Pollinations → fallback Cloudflare) ──► un png por escena
   │
   ▼
4. ANIMACIÓN (FFmpeg Ken Burns) ──► un mp4 por escena (zoom/pan, 4 variantes)
   │
   ▼
5. ⏸ REVISIÓN HUMANA OBLIGATORIA (pausa el script, revisas tú)
   │
   ▼
6. SUBTÍTULOS (Whisper local) + MONTAJE FINAL (FFmpeg) ──► video_final.mp4
   │
   ▼
GitHub Actions "artifact" ──► notificación en la app de GitHub → tú descargas y ves el vídeo
   │
   ▼
   (subida manual a YouTube por ahora — la automatizamos en el último paso,
    cuando todo lo anterior esté probado y sea estable)
```

**Cómo lo disparas tú:** desde la app de GitHub en el móvil, entras al repo, pulsas "Run workflow", escribes el título que yo te doy, y ya. Nada de Telegram, nada de Drive, nada nuevo que aprender.

## Archivos ya creados (`/home/claude/ultima_senal/`)

| Archivo | Qué hace | Estado |
|---|---|---|
| `generar_guion.py` | Groq genera guion + prompts de imagen por escena | Escrito, sin probar |
| `generar_voz.py` | Edge TTS, un audio por escena, mide duración | Escrito, sin probar |
| `generar_imagen.py` | Pollinations → Cloudflare → Hugging Face (3 proveedores en cascada) + validación | Escrito, sin probar |
| `animar_imagen.py` | Ken Burns con FFmpeg, 4 variantes de movimiento | Escrito, sin probar |
| `generar_subtitulos.py` | Whisper local → .srt | Escrito, sin probar |
| `montar_video.py` | Concatena todo, quema subtítulos, exporta final | Escrito, sin probar |
| `pipeline.py` | Orquesta los 6 pasos, con pausa de revisión humana | Escrito, sin probar |

**Nada de esto está probado todavía.** Es la estructura completa, tal como pediste, para que la veas entera de una vez. Ahora toca ir pieza por pieza, ejecutando de verdad y arreglando lo que falle.

## Lo que YA está blindado (fallbacks / validación)

- **Imágenes:** 2 proveedores (Pollinations + Cloudflare), reintentos, validación de que el archivo no esté vacío/corrupto.
- **Guion:** 2 modelos de Groq (120b con fallback a 20b), validación de que el JSON venga completo.
- **Voz:** reintento si Edge TTS falla, validación de tamaño de archivo.

## Lo que TODAVÍA no está blindado (hay que endurecerlo paso a paso)

- FFmpeg (animación y montaje) no tiene reintentos ni fallback — si falla, el pipeline se para en seco. Hay que decidir qué hacer si una escena de vídeo sale mal.
- Whisper no tiene fallback si falla la transcripción.
- No hay verificación automática de que la imagen generada realmente corresponda al prompt (esto no es fácil de automatizar gratis; probablemente esa parte se queda en manos de tu revisión humana en el paso 5).
- No hay manejo de qué pasa si el pipeline se cae a mitad (por ahora habría que relanzarlo desde el paso que falló a mano).
- Sin conexión a ActivePieces todavía — de momento todo se ejecuta a mano en local o en un runner.

## Orden que propongo para ir "blindando" paso a paso

1. **Imágenes** (ya montado) → tú lo pruebas con `--test`, vemos si Pollinations/Cloudflare responden bien y si el estilo convence.
2. **Guion** → probar con un tema real, revisar que el JSON salga bien formado y el contenido tenga el tono correcto.
3. **Voz** → probar que Edge TTS suene bien y que las duraciones cuadren.
4. **Animación (FFmpeg)** → probar con una imagen real, ver que el zoom se vea bien y no dé tirones.
5. **Montaje + subtítulos** → juntar todo en un vídeo de prueba corto (2-3 escenas) antes de lanzar uno de 8 minutos completo.
6. **Pipeline completo** → un vídeo de principio a fin, revisado a mano en el paso 5 antes de exportar.
7. Solo cuando 1-6 sean estables: conectar subida (manual primero, API después) y automatización de cadencia.

Empezamos por el paso 1 (imágenes), que es lo único que ya tienes listo para probar. En cuanto tengas Cloudflare configurado, corre `python generar_imagen.py --test` y me pasas resultado y las 4 imágenes.
