"""
Última Señal — Orquestador del pipeline completo
====================================================
Ejecuta todos los pasos en orden, CON una pausa obligatoria de revisión
humana antes del montaje final (esto es lo que te saca de "cero
intervención humana" frente a la política de inauthentic content de YouTube).

Uso:
    python pipeline.py "Tema del accidente aéreo"

Requisitos previos (variables de entorno):
    GROQ_API_KEY
    CF_ACCOUNT_ID, CF_API_TOKEN   (fallback de imágenes)
"""

import os
import sys
import json

from generar_guion import generar_guion
from generar_imagen import generar_imagen
from generar_voz import generar_voces
from animar_imagen import animar_todas
from generar_subtitulos import generar_srt
from montar_video import montar_video_final


def ejecutar_pipeline(tema: str, carpeta_proyecto: str):
    os.makedirs(carpeta_proyecto, exist_ok=True)

    # 1. GUION -----------------------------------------------------------
    print("\n=== PASO 1/6: Generando guion ===")
    ruta_guion = os.path.join(carpeta_proyecto, "guion.json")
    guion = generar_guion(tema)
    with open(ruta_guion, "w", encoding="utf-8") as f:
        json.dump(guion, f, ensure_ascii=False, indent=2)
    print(f"Título propuesto: {guion['titulo_video']}")
    print(f"{len(guion['escenas'])} escenas generadas.")

    # 2. VOZ (se genera antes que la imagen para saber la duración exacta)
    print("\n=== PASO 2/6: Generando voz ===")
    carpeta_audio = os.path.join(carpeta_proyecto, "audio")
    info_escenas = generar_voces(ruta_guion, carpeta_audio)

    # 3. IMÁGENES ----------------------------------------------------------
    print("\n=== PASO 3/6: Generando imágenes ===")
    carpeta_imagenes = os.path.join(carpeta_proyecto, "imagenes")
    os.makedirs(carpeta_imagenes, exist_ok=True)
    fallos = []
    for escena in info_escenas:
        ruta_img = os.path.join(carpeta_imagenes, f"escena_{escena['indice']:02d}.png")
        print(f"  Escena {escena['indice']}/{len(info_escenas)}")
        ok = generar_imagen(escena["prompt_imagen"], ruta_img)
        if not ok:
            fallos.append(escena["indice"])

    if fallos:
        print(f"\n⚠ ATENCIÓN: fallaron las imágenes de las escenas {fallos}")
        print("Revísalas y vuelve a generarlas manualmente antes de seguir.")
        return

    # 4. ANIMACIÓN (Ken Burns) --------------------------------------------
    print("\n=== PASO 4/6: Animando imágenes (Ken Burns) ===")
    carpeta_clips = os.path.join(carpeta_proyecto, "clips")
    animar_todas(info_escenas, carpeta_imagenes, carpeta_clips)

    # 5. PAUSA DE REVISIÓN HUMANA ------------------------------------------
    print("\n" + "=" * 60)
    print("PASO 5/6: REVISIÓN HUMANA OBLIGATORIA")
    print("=" * 60)
    print(f"Revisa ahora:")
    print(f"  - Guion:    {ruta_guion}")
    print(f"  - Imágenes: {carpeta_imagenes}")
    print(f"  - Clips:    {carpeta_clips}")
    print("\nEste paso es importante: revisa que las imágenes encajen con el")
    print("texto, que no haya nada gráfico/sensible, y ajusta lo que haga falta")
    print("a mano antes de continuar. Esto es lo que mantiene el canal fuera")
    print("del radar de 'inauthentic content' de YouTube.")
    respuesta = input("\n¿Todo revisado y aprobado? (s/n): ").strip().lower()
    if respuesta != "s":
        print("Pipeline pausado. Vuelve a ejecutar el paso de montaje cuando esté todo aprobado.")
        return

    # 6. SUBTÍTULOS + MONTAJE FINAL ----------------------------------------
    print("\n=== PASO 6/6: Subtítulos y montaje final ===")
    # concatenar audio primero solo para poder transcribirlo
    from montar_video import _concatenar_audios
    audio_completo = os.path.join(carpeta_proyecto, "audio_completo_temp.mp3")
    _concatenar_audios([e["ruta_audio"] for e in info_escenas], audio_completo)

    ruta_srt = os.path.join(carpeta_proyecto, "subtitulos.srt")
    generar_srt(audio_completo, ruta_srt)
    os.remove(audio_completo)

    ruta_final = os.path.join(carpeta_proyecto, "video_final.mp4")
    info_escenas_path = os.path.join(carpeta_audio, "info_escenas.json")
    montar_video_final(carpeta_clips, carpeta_audio, ruta_srt, ruta_final, info_escenas_path)

    print(f"\n✓✓✓ PIPELINE COMPLETO. Vídeo en: {ruta_final}")
    print("Recuerda: NO lo subas automáticamente todavía. Míralo entero tú primero.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python pipeline.py 'Tema del accidente aéreo'")
        sys.exit(1)
    tema_arg = " ".join(sys.argv[1:])
    carpeta = "proyecto_" + "".join(c if c.isalnum() else "_" for c in tema_arg.lower())[:40]
    ejecutar_pipeline(tema_arg, carpeta)
